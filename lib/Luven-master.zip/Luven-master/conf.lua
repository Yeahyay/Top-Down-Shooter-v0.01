function love.conf(t)
    t.window.title = "Luven - Exemple"
    t.window.width = 1280
    t.window.height = 720
    t.window.display = 3
    t.window.highdpi = false
    t.window.vsync = 1
    t.window.msaa = 0
    t.gammacorrect = false

    t.console = true
end
